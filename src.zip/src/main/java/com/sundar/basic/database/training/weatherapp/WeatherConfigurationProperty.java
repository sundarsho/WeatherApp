package com.sundar.basic.database.training.weatherapp;

public class WeatherConfigurationProperty {
}
